// Tea Room v2 — clickable marketplace built on landing direction A.
// Home shows a 3×2 grid (or marquee) of app-store icons; clicking any
// icon opens its app page. Spiral lifted from variant B replaces the
// doodle in the foot row.

const HERO_COPIES = {
  rooms: 'a small marketplace of apps that work less like products and more like rooms. open one, sit a minute, close the tab. a new room opens every few days.',
  welcome: 'welcome to the tea room — a marketplace of small soft apps made between songs and poems. nothing here you need, everything here you can sit inside for a minute.',
  vibe: 'the tea room is a marketplace of small soft apps. each one was vibe-coded in a sitting or two — half art, half utility, all slightly impractical. step in, take one home.',
};

const HERO_COPY_OPTIONS = [
  { value: 'rooms',   label: 'rooms, not products' },
  { value: 'welcome', label: 'welcome / soft apps' },
  { value: 'vibe',    label: 'vibe-coded, slightly impractical' },
];

function TeaRoom() {
  const [route, setRoute] = React.useState('home');
  const [trans, setTrans] = React.useState(0);
  const nav = (r) => { if (r === route) return; setRoute(r); setTrans((t) => t + 1); };

  // Tweaks
  const [t, setTweak] = useTweaks(/*EDITMODE-BEGIN*/{
    "heroCopy": "rooms",
    "marketplaceLayout": "grid",
    "showSpiral": true,
    "showBrewing": true
  }/*EDITMODE-END*/);

  let body;
  if (route === 'home') body = <TRHome nav={nav} t={t} />;
  else if (route === 'info') body = <TRInfo nav={nav} />;
  else if (route === 'play') body = <TRPlay nav={nav} />;
  else if (route.startsWith('app:')) {
    const app = APPS.find((a) => a.slug === route.slice(4));
    const soon = SOON.find((s) => s.slug === route.slice(4));
    body = app ? <TRAppDetail app={app} nav={nav} /> : (soon ? <TRBrewing app={soon} nav={nav} /> : <TRHome nav={nav} t={t} />);
  }

  return (
    <div style={{
      minHeight: '100vh', background: PINK, color: INK,
      fontFamily: 'var(--display)', display: 'flex', flexDirection: 'column',
    }}>
      <TRTopNav route={route} nav={nav} />
      <div key={trans} style={{ flex: 1, animation: 'tr-fade .35s cubic-bezier(.2,.7,.3,1) both' }}>
        {body}
      </div>
      <TweaksPanel title="Tweaks">
        <TweakSection label="Copy">
          <TweakRadio label="Hero" value={t.heroCopy} options={HERO_COPY_OPTIONS}
            onChange={(v) => setTweak('heroCopy', v)} />
        </TweakSection>
        <TweakSection label="Layout">
          <TweakRadio label="Marketplace" value={t.marketplaceLayout}
            options={[{ value: 'grid', label: 'Grid' }, { value: 'marquee', label: 'Marquee' }]}
            onChange={(v) => setTweak('marketplaceLayout', v)} />
          <TweakToggle label="Spiral in foot" value={t.showSpiral}
            onChange={(v) => setTweak('showSpiral', v)} />
          <TweakToggle label="Show brewing" value={t.showBrewing}
            onChange={(v) => setTweak('showBrewing', v)} />
        </TweakSection>
      </TweaksPanel>
      <style>{`
        @keyframes tr-fade { from { opacity: 0; transform: translateY(6px) } to { opacity: 1; transform: none } }
        .stagger > * { animation: tr-fade .45s cubic-bezier(.2,.7,.3,1) both }
        .stagger > *:nth-child(1) { animation-delay: .02s }
        .stagger > *:nth-child(2) { animation-delay: .07s }
        .stagger > *:nth-child(3) { animation-delay: .12s }
        .stagger > *:nth-child(4) { animation-delay: .17s }
        .stagger > *:nth-child(5) { animation-delay: .22s }
        .stagger > *:nth-child(6) { animation-delay: .27s }
      `}</style>
    </div>
  );
}

// ─── top nav ─────────────────────────────────────────────────
function TRTopNav({ route, nav }) {
  const items = ['Work', 'Play', 'Info'];
  const cell = { fontFamily: 'var(--mono)', fontSize: 12, letterSpacing: '.02em', color: INK };
  const onWorkClick = () => nav('home');
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', alignItems: 'center', padding: '20px 48px', borderBottom: `1px solid ${RULE}` }}>
      <div style={cell}>designer, poet, vibe-coder</div>
      <a href="#" onClick={(e) => { e.preventDefault(); nav('home'); }} style={{ ...cell, fontWeight: 500, textDecoration: 'none' }}>ayesha&apos;s tea room</a>
      <div style={{ ...cell, display: 'flex', gap: 18, justifyContent: 'flex-end' }}>
        {items.map((r) => {
          const k = r.toLowerCase();
          const active = (k === 'work' && route === 'home') || route === k || (k === 'work' && route.startsWith('app:'));
          return (
            <a key={r} href="#" onClick={(e) => { e.preventDefault(); k === 'work' ? onWorkClick() : nav(k); }}
               style={{ color: INK, textDecoration: active ? 'underline' : 'none', textUnderlineOffset: 4 }}
               onMouseEnter={(e) => (e.currentTarget.style.textDecoration = 'underline')}
               onMouseLeave={(e) => (e.currentTarget.style.textDecoration = active ? 'underline' : 'none')}>
              {r}
            </a>
          );
        })}
      </div>
    </div>
  );
}

// ─── home ────────────────────────────────────────────────────
function TRHome({ nav, t }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      {/* hero */}
      <div style={{ padding: '64px 48px 40px' }} className="stagger">
        <h1 style={{
          fontFamily: 'var(--display)', fontWeight: 500,
          fontSize: 'clamp(48px, 6.2vw, 84px)',
          lineHeight: 1.02, letterSpacing: '-.035em',
          margin: 0, textWrap: 'pretty', maxWidth: '17ch',
        }}>
          {HERO_COPIES[t.heroCopy]}
        </h1>
      </div>

      {/* marketplace */}
      <div style={{ padding: '8px 48px 8px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 18, borderBottom: `1px solid ${RULE}`, paddingBottom: 14 }}>
          <div style={{
            fontFamily: 'var(--display)', fontSize: 28, fontWeight: 400,
            fontStyle: 'italic', letterSpacing: '-.02em', color: INK,
          }}>
            the marketplace —
          </div>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: MUTE, letterSpacing: '.02em' }}>
            {APPS.length} open · {SOON.length} brewing
          </div>
        </div>

        {t.marketplaceLayout === 'grid'
          ? <MarketGrid nav={nav} showBrewing={t.showBrewing} />
          : <MarketMarquee nav={nav} showBrewing={t.showBrewing} />}
      </div>

      {/* divider marquee — names cycling, matches reference */}
      <div style={{ marginTop: 36 }}>
        <Marquee items={[...APPS.map((a) => a.title), ...SOON.map((s) => s.title), 'tea room', 'worry jar', 'pocket garden']} />
      </div>

      {/* foot row */}
      <div style={{ padding: '36px 48px 28px', display: 'grid', gridTemplateColumns: 'auto 1fr auto auto', gap: 56, alignItems: 'center' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          <ArrowLink onClick={() => window.scrollTo({ top: document.body.scrollHeight * .2, behavior: 'smooth' })}>Work</ArrowLink>
          <ArrowLink onClick={() => nav('play')}>Play</ArrowLink>
          <ArrowLink onClick={() => nav('info')}>Info</ArrowLink>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 28 }}>
          {t.showSpiral && <SpiralMark size={120} color={INK} />}
          <div style={{ fontSize: 28, fontWeight: 500, letterSpacing: '-.02em', lineHeight: 1.1, maxWidth: '24ch' }}>
            a portfolio of vibe-coded little apps,<br />updated whenever the room is warm.
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, fontFamily: 'var(--mono)', fontSize: 13 }}>
          <a href="#" style={{ color: INK, textDecoration: 'none' }}>↗ are.na</a>
          <a href="#" style={{ color: INK, textDecoration: 'none' }}>↗ github</a>
          <a href="#" style={{ color: INK, textDecoration: 'none' }}>↗ letters</a>
        </div>
        <div />
      </div>

      <MiniFoot />
    </div>
  );
}

// ─── spiral mark (lifted from B's vibe) ───────────────────────
function SpiralMark({ size = 120, color = INK }) {
  return (
    <svg viewBox="0 0 140 140" width={size} height={size} style={{ overflow: 'visible', flexShrink: 0 }}>
      <path d="M70 70 m -3 0 a 3 3 0 1 1 6 0 a 10 10 0 1 1 -20 0 a 20 20 0 1 1 40 0 a 32 32 0 1 1 -64 0 a 46 46 0 1 1 92 0"
            fill="none" stroke={color} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// ─── marketplace grid ────────────────────────────────────────
function MarketGrid({ nav, showBrewing }) {
  const items = [
    ...APPS.map((a) => ({ kind: 'live', app: a })),
    ...(showBrewing ? SOON.map((a) => ({ kind: 'brew', app: a })) : []),
  ];
  return (
    <div className="stagger" style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18 }}>
      {items.map(({ kind, app }) => (
        <MarketCard key={app.slug} app={app} kind={kind}
          onOpen={() => nav('app:' + app.slug)} />
      ))}
    </div>
  );
}

function MarketCard({ app, kind, onOpen }) {
  const [hov, setHov] = React.useState(false);
  const live = kind === 'live';
  const accent = live ? app.accent : 'rgba(26,20,20,.55)';
  const bg = live ? app.color : '#ece4e6';
  return (
    <div onClick={live ? onOpen : undefined}
         onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
         style={{
           display: 'flex', alignItems: 'center', gap: 16, padding: 18,
           border: `1px solid ${RULE}`, borderRadius: 16,
           background: hov && live ? 'rgba(255,255,255,.5)' : 'rgba(255,255,255,.18)',
           cursor: live ? 'pointer' : 'default',
           transition: 'background .2s, transform .25s, box-shadow .25s',
           transform: hov && live ? 'translateY(-2px)' : 'none',
           boxShadow: hov && live ? '0 8px 24px rgba(20,10,10,.06)' : 'none',
           opacity: live ? 1 : .68,
         }}>
      <AppIcon slug={app.slug} size={84} bg={bg} mark={accent} />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: MUTE, letterSpacing: '.06em', textTransform: 'uppercase' }}>
          {live ? (app.medium && app.medium[0]) : 'brewing'}
        </div>
        <div style={{ fontSize: 22, fontWeight: 500, letterSpacing: '-.025em', lineHeight: 1.05, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {app.title}
        </div>
        <div style={{ fontSize: 13, color: MUTE, fontStyle: 'italic', lineHeight: 1.3,
          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
          {app.tag}
        </div>
      </div>
      <button onClick={(e) => { e.stopPropagation(); if (live) onOpen(); }}
        style={{
          flexShrink: 0,
          border: 'none', borderRadius: 999,
          background: live ? INK : 'transparent',
          color: live ? PINK : MUTE,
          padding: live ? '8px 16px' : '8px 14px',
          fontFamily: 'var(--mono)', fontSize: 12, fontWeight: 500, letterSpacing: '.04em',
          textTransform: 'uppercase', cursor: live ? 'pointer' : 'default',
          border: live ? 'none' : `1px dashed ${RULE}`,
        }}>
        {live ? 'open' : 'soon'}
      </button>
    </div>
  );
}

// ─── marketplace marquee ─────────────────────────────────────
function MarketMarquee({ nav, showBrewing }) {
  const items = [
    ...APPS.map((a) => ({ kind: 'live', app: a })),
    ...(showBrewing ? SOON.map((a) => ({ kind: 'brew', app: a })) : []),
  ];
  // duplicate so the marquee loops seamlessly
  const ref = React.useRef(null);
  const [paused, setPaused] = React.useState(false);
  return (
    <div style={{ position: 'relative', overflow: 'hidden', borderTop: `1px solid ${RULE}`, borderBottom: `1px solid ${RULE}`, padding: '24px 0' }}
         onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <div ref={ref} style={{
        display: 'inline-flex', gap: 18,
        animation: `tr-mq 40s linear infinite`,
        animationPlayState: paused ? 'paused' : 'running',
      }}>
        {[0, 1].map((k) => (
          <div key={k} style={{ display: 'inline-flex', gap: 18, paddingRight: 18 }}>
            {items.map(({ kind, app }) => (
              <MarqueeIcon key={k + app.slug} app={app} kind={kind}
                onOpen={() => kind === 'live' && nav('app:' + app.slug)} />
            ))}
          </div>
        ))}
      </div>
      <style>{`@keyframes tr-mq { from { transform: translateX(0) } to { transform: translateX(-50%) } }`}</style>
    </div>
  );
}

function MarqueeIcon({ app, kind, onOpen }) {
  const live = kind === 'live';
  const [hov, setHov] = React.useState(false);
  return (
    <button onClick={onOpen} disabled={!live}
            onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
            style={{
              border: 'none', background: 'transparent', padding: 0,
              cursor: live ? 'pointer' : 'default', textAlign: 'center',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
              minWidth: 110, opacity: live ? 1 : .55,
              transform: hov && live ? 'translateY(-3px)' : 'none', transition: 'transform .25s',
            }}>
      <AppIcon slug={app.slug} size={88} bg={live ? app.color : '#ece4e6'} mark={live ? app.accent : MUTE} />
      <div style={{ fontFamily: 'var(--display)', fontSize: 14, fontWeight: 500, color: INK, letterSpacing: '-.01em' }}>
        {app.title}
      </div>
      <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: MUTE, letterSpacing: '.06em', textTransform: 'uppercase' }}>
        {live ? 'open' : 'brewing'}
      </div>
    </button>
  );
}

// ─── app detail ──────────────────────────────────────────────
function TRAppDetail({ app, nav }) {
  const idx = APPS.findIndex((a) => a.slug === app.slug);
  const next = APPS[(idx + 1) % APPS.length];

  return (
    <div>
      {/* breadcrumbs */}
      <div style={{ padding: '24px 48px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontFamily: 'var(--mono)', fontSize: 12, color: MUTE }}>
        <a href="#" onClick={(e) => { e.preventDefault(); nav('home'); }} style={{ color: MUTE, textDecoration: 'none' }}>← back to the room</a>
        <span>{app.n} of {APPS.length.toString().padStart(2, '0')}</span>
      </div>

      {/* hero band — icon + name + description, app-store-detail vibe */}
      <div className="stagger" style={{ padding: '28px 48px 36px', display: 'grid', gridTemplateColumns: 'auto 1fr', gap: 32, alignItems: 'center' }}>
        <AppIcon slug={app.slug} size={156} bg={app.color} mark={app.accent} radius={36} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: app.accent, letterSpacing: '.08em', textTransform: 'uppercase' }}>
            ●  {app.medium.join(' · ')}  ·  {app.year}
          </div>
          <h1 style={{ fontFamily: 'var(--display)', fontWeight: 500, fontSize: 'clamp(40px, 6vw, 80px)', letterSpacing: '-.04em', lineHeight: .95, margin: 0 }}>
            {app.title}
          </h1>
          <div style={{ fontSize: 22, color: MUTE, fontStyle: 'italic', letterSpacing: '-.015em', marginTop: 2 }}>
            {app.tag}
          </div>
          <div style={{ display: 'flex', gap: 12, marginTop: 14, flexWrap: 'wrap' }}>
            <button style={{
              border: 'none', background: INK, color: PINK, padding: '12px 22px', borderRadius: 999,
              fontFamily: 'var(--mono)', fontSize: 12, fontWeight: 500, letterSpacing: '.06em',
              textTransform: 'uppercase', cursor: 'pointer',
              display: 'inline-flex', alignItems: 'center', gap: 10,
            }}>
              open {app.title} <span>↗</span>
            </button>
            <button style={{
              border: `1px solid ${INK}`, background: 'transparent', color: INK, padding: '11px 22px', borderRadius: 999,
              fontFamily: 'var(--mono)', fontSize: 12, fontWeight: 500, letterSpacing: '.06em', textTransform: 'uppercase', cursor: 'pointer',
            }}>
              save for later
            </button>
          </div>
        </div>
      </div>

      {/* description + preview placeholder */}
      <div style={{ padding: '0 48px 36px', display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 40, alignItems: 'flex-start' }}>
        <div>
          <h3 style={{ fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '.08em', textTransform: 'uppercase', color: MUTE, margin: '0 0 12px' }}>about this room</h3>
          <p style={{ fontSize: 19, lineHeight: 1.5, margin: 0, maxWidth: '52ch' }}>{app.desc}</p>
          <p style={{ fontSize: 16, lineHeight: 1.55, marginTop: 18, color: 'rgba(26,20,20,.7)', maxWidth: '52ch' }}>
            i wanted this to feel like one of those rooms in a friend&apos;s house where everyone ends up sitting on the floor. small footprint, low lighting, nothing to optimise. arrive, do the thing, close the tab.
          </p>
        </div>
        <div style={{
          aspectRatio: '4 / 5', background: app.color, borderRadius: 18, position: 'relative',
          display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
          backgroundImage: `repeating-linear-gradient(135deg, rgba(255,255,255,.0) 0 22px, rgba(255,255,255,.18) 22px 23px)`,
        }}>
          <div style={{ position: 'absolute', top: 16, left: 18, fontFamily: 'var(--mono)', fontSize: 11, color: app.accent, opacity: .85 }}>
            preview · placeholder
          </div>
          <AppIcon slug={app.slug} size={180} bg="rgba(255,255,255,.55)" mark={app.accent} radius={42} />
          <div style={{ position: 'absolute', bottom: 16, right: 18, fontFamily: 'var(--mono)', fontSize: 11, color: app.accent, opacity: .7 }}>
            drop screenshot here
          </div>
        </div>
      </div>

      {/* meta strip */}
      <div style={{ borderTop: `1px solid ${RULE}`, borderBottom: `1px solid ${RULE}`, padding: '18px 48px', display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 24, fontFamily: 'var(--mono)', fontSize: 12 }}>
        <DMeta k="status" v="open & steeping" />
        <DMeta k="built in" v="3 evenings" />
        <DMeta k="stack" v="react · web audio · localstorage" />
        <DMeta k="changelog" v="v0.4 — added quiet mode" />
      </div>

      {/* next */}
      <a href="#" onClick={(e) => { e.preventDefault(); nav('app:' + next.slug); }}
         style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '32px 48px',
           color: INK, textDecoration: 'none', background: next.color + '88',
           transition: 'background .2s' }}>
        <span style={{ fontFamily: 'var(--mono)', fontSize: 12, color: 'rgba(26,20,20,.6)' }}>next room —</span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          <AppIcon slug={next.slug} size={56} bg={'rgba(255,255,255,.45)'} mark={next.accent} radius={14} />
          <span style={{ fontSize: 36, fontWeight: 500, letterSpacing: '-.03em' }}>{next.title}  →</span>
        </span>
      </a>

      <MiniFoot />
    </div>
  );
}

function DMeta({ k, v }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <span style={{ color: MUTE, letterSpacing: '.06em', textTransform: 'uppercase', fontSize: 10 }}>{k}</span>
      <span style={{ color: INK }}>{v}</span>
    </div>
  );
}

// ─── brewing detail ──────────────────────────────────────────
function TRBrewing({ app, nav }) {
  return (
    <div style={{ padding: '60px 48px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20, textAlign: 'center' }}>
      <AppIcon slug={app.slug} size={140} bg="#ece4e6" mark={MUTE} radius={32} />
      <h1 style={{ fontFamily: 'var(--display)', fontWeight: 500, fontSize: 56, letterSpacing: '-.04em', margin: 0 }}>{app.title}</h1>
      <div style={{ fontSize: 20, color: MUTE, fontStyle: 'italic' }}>{app.tag}</div>
      <div style={{ fontFamily: 'var(--mono)', fontSize: 12, color: MUTE, letterSpacing: '.06em', textTransform: 'uppercase' }}>still brewing — back in a few days</div>
      <button onClick={() => nav('home')} style={{
        marginTop: 12, border: `1px solid ${INK}`, background: 'transparent', color: INK,
        padding: '11px 22px', borderRadius: 999, fontFamily: 'var(--mono)', fontSize: 12,
        fontWeight: 500, letterSpacing: '.06em', textTransform: 'uppercase', cursor: 'pointer',
      }}>← back to the room</button>
    </div>
  );
}

// ─── info ────────────────────────────────────────────────────
function TRInfo({ nav }) {
  return (
    <div>
      <div style={{ padding: '48px 48px', display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 56 }}>
        <div>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 12, color: MUTE, letterSpacing: '.08em', textTransform: 'uppercase' }}>info — about the room</div>
          <h2 style={{ fontFamily: 'var(--display)', fontWeight: 500, fontSize: 56, letterSpacing: '-.04em', margin: '12px 0 18px', lineHeight: 1.02 }}>
            hi, i&apos;m ayesha. i make ecosystems of experience.
          </h2>
          <p style={{ fontSize: 19, lineHeight: 1.55, maxWidth: '50ch', margin: 0 }}>
            i blend experimental graphic design, music production, poetry, and software into projects that are usually small, sometimes useless, occasionally moving. the tea room is where i put all of them while they finish brewing.
          </p>
          <p style={{ fontSize: 17, lineHeight: 1.55, maxWidth: '50ch', marginTop: 18, color: 'rgba(26,20,20,.7)' }}>
            most of these apps were vibe-coded in an evening or two. some never get finished. that&apos;s the point — the marketplace is the journal. come back in a few days, there&apos;ll be another room.
          </p>
          <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 6 }}>
            <ArrowLink onClick={() => nav('home')} size={22}>see what&apos;s open</ArrowLink>
            <ArrowLink onClick={() => nav('play')} size={22}>poke at the scraps</ArrowLink>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
          <TRInfoCard title="elsewhere" rows={[['are.na', '↗'], ['github', '↗'], ['letters (substack)', '↗'], ['email', 'hello @ tea.room']]} />
          <TRInfoCard title="now (may 2026)" rows={[['reading', 'le guin essays'], ['listening', 'arthur russell loops'], ['making', 'lullaby machine'], ['drinking', 'genmaicha, lots']]} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '18px 22px', border: `1px solid ${RULE}`, borderRadius: 12 }}>
            <SpiralMark size={48} color={INK} />
            <div style={{ fontFamily: 'var(--mono)', fontSize: 12, color: MUTE, lineHeight: 1.5 }}>
              this site refreshes every few days as new rooms open. you can subscribe to letters for a quiet weekly note.
            </div>
          </div>
        </div>
      </div>
      <MiniFoot />
    </div>
  );
}

function TRInfoCard({ title, rows }) {
  return (
    <div style={{ border: `1px solid ${RULE}`, borderRadius: 12, padding: 20 }}>
      <div style={{ fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '.08em', textTransform: 'uppercase', color: MUTE, marginBottom: 14 }}>{title}</div>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {rows.map(([k, v]) => (
          <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderTop: `1px dotted ${RULE}`, fontSize: 14 }}>
            <span style={{ color: INK }}>{k}</span>
            <span style={{ fontFamily: 'var(--mono)', fontSize: 12, color: MUTE }}>{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── play (scraps) ───────────────────────────────────────────
function TRPlay({ nav }) {
  const items = [
    { name: 'fortune cookie', tag: 'click for a small inscrutable line', kind: 'toy' },
    { name: 'kettle whistle', tag: 'a sound piece, 3 mins', kind: 'sound' },
    { name: 'thursday poem', tag: 'a poem rewritten every thursday', kind: 'poem' },
    { name: 'pink walk', tag: 'cursor follower with a soft tail', kind: 'toy' },
    { name: 'voice memo', tag: 'unfinished song about a window', kind: 'sound' },
    { name: 'three things', tag: 'a list of three things from today', kind: 'note' },
  ];
  return (
    <div>
      <div style={{ padding: '40px 48px 8px' }}>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 12, color: MUTE, letterSpacing: '.08em', textTransform: 'uppercase' }}>play — scraps</div>
        <h2 style={{ fontFamily: 'var(--display)', fontWeight: 500, fontSize: 56, letterSpacing: '-.04em', margin: '12px 0 16px', maxWidth: '22ch' }}>
          little things that aren&apos;t quite apps but still wanted to be made.
        </h2>
      </div>
      <div className="stagger" style={{ padding: '12px 48px 40px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {items.map((it, i) => (
          <div key={it.name} style={{
            border: `1px solid ${RULE}`, borderRadius: 12, padding: 22,
            display: 'flex', flexDirection: 'column', gap: 8, minHeight: 170,
            background: i % 2 ? 'transparent' : 'rgba(255,255,255,.25)',
            cursor: 'pointer', transition: 'transform .2s, background .2s',
          }}
          onMouseEnter={(e) => { e.currentTarget.style.transform = 'translateY(-2px)'; e.currentTarget.style.background = 'rgba(255,255,255,.45)'; }}
          onMouseLeave={(e) => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.background = i % 2 ? 'transparent' : 'rgba(255,255,255,.25)'; }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: MUTE, letterSpacing: '.08em', textTransform: 'uppercase' }}>{it.kind}</span>
              <Blob size={28} color={INK} variant={['squiggle', 'wave', 'loop'][i % 3]} />
            </div>
            <div style={{ fontSize: 24, fontWeight: 500, letterSpacing: '-.025em', marginTop: 'auto' }}>{it.name}</div>
            <div style={{ fontSize: 13, color: MUTE, fontStyle: 'italic' }}>{it.tag}</div>
          </div>
        ))}
      </div>
      <MiniFoot />
    </div>
  );
}

Object.assign(window, { TeaRoom });
